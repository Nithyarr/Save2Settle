﻿using RPT.Models;
using System.Text.Json;

namespace RPT.Data
{
    public class JsonDataService
    {
        private readonly string _filePath = "data.json";

        public List<RetirementGoal> LoadAllGoals()
        {
            try
            {
                if (!File.Exists(_filePath)) return new List<RetirementGoal>();
                var json = File.ReadAllText(_filePath);
                return JsonSerializer.Deserialize<List<RetirementGoal>>(json) ?? new List<RetirementGoal>();
            }
            catch (Exception ex)
            {
                throw new Exception("Error loading retirement goals from file.", ex);
            }
        }

        public void SaveGoal(RetirementGoal goal)
        {
            try
            {
                var goals = LoadAllGoals();
                int nextNumber = 1;

                if (goals.Any())
                {
                    var lastId = goals
                        .Select(g => int.TryParse(g.Id.Replace("RPT", ""), out var num) ? num : 0)
                        .Max();

                    nextNumber = lastId + 1;
                }

                goal.Id = $"RPT{nextNumber.ToString("D3")}";
                goals.Add(goal);

                File.WriteAllText(_filePath, JsonSerializer.Serialize(goals));
            }
            catch (Exception ex)
            {
                throw new Exception("Error saving retirement goal.", ex);
            }
        }

        public void UpdateGoal(RetirementGoal updatedGoal)
        {
            try
            {
                var goals = LoadAllGoals();
                var index = goals.FindIndex(g => g.Id == updatedGoal.Id);

                if (index != -1)
                {
                    goals[index] = updatedGoal;
                    File.WriteAllText(_filePath, JsonSerializer.Serialize(goals));
                }
                else
                {
                    throw new Exception("Retirement goal not found.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error updating retirement goal.", ex);
            }
        }

        public RetirementGoal? GetGoalById(string id)
        {
            try
            {
                return LoadAllGoals().FirstOrDefault(g => g.Id == id);
            }
            catch (Exception ex)
            {
                throw new Exception("Error retrieving retirement goal by ID.", ex);
            }
        }
    }
}