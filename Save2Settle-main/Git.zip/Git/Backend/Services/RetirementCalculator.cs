﻿namespace RPT.Services
{
    public static class RetirementCalculator
    {
        public static double CalculateRequiredMonthlyContribution(
            double currentSavings,
            double targetSavings,
            int currentAge,
            int retirementAge,
            double annualInterestRatePercent)
        {
            try
            {
                if (currentAge >= retirementAge)
                    throw new ArgumentException("Current age must be less than retirement age.");

                if (annualInterestRatePercent <= 0)
                    throw new ArgumentException("Annual interest rate must be greater than zero.");

                double r = annualInterestRatePercent / 100 / 12;
                int n = (retirementAge - currentAge) * 12;
                double compoundFactor = Math.Pow(1 + r, n);
                double futureValueOfCurrentSavings = currentSavings * compoundFactor;
                double annuityFactor = (compoundFactor - 1) / r;
                
                double monthlyContribution = (targetSavings - futureValueOfCurrentSavings) / annuityFactor;
                
                return monthlyContribution;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in CalculateRequiredMonthlyContribution: {ex.Message}");
                return 0;
            }
        }

        public static double CalculateFutureValue(
            double currentSavings,
            double monthlySavings,
            double annualInterestRate,
            int retirementAge,
            int currentAge)
        {
            try
            {
                if (currentAge >= retirementAge)
                    throw new ArgumentException("Current age must be less than retirement age.");

                if (annualInterestRate <= 0)
                    throw new ArgumentException("Annual interest rate must be greater than zero.");

                double monthlyRate = annualInterestRate / 12 / 100;
                int totalMonths = (retirementAge - currentAge) * 12;

                double compoundedSavings = currentSavings * Math.Pow(1 + monthlyRate, totalMonths);
                double compoundedContributions = monthlySavings *
                                                 (Math.Pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate;

                return compoundedSavings + compoundedContributions;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in CalculateFutureValue: {ex.Message}");
                return 0;
            }
        }
    }
}