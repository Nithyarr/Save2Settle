using Microsoft.Extensions.Configuration;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Threading.Tasks;

namespace RPT.Services
{
    public interface IEmailService
    {
        Task<bool> SendReferenceIdEmailAsync(string toEmail, string referenceId);
    }

    public class EmailService : IEmailService
    {
        private readonly string? _sendGridApiKey;
        private readonly string? _templateId = "d-032f6ae089a64b45ac8ca52f3a82cc4b";
        private readonly string? _fromEmail = "save2settle@gmail.com";
        private readonly string? _fromName = "Save2Settle Team";

        public EmailService(IConfiguration configuration)
        {
            _sendGridApiKey = configuration["SendGrid:ApiKey"];
        }

        public async Task<bool> SendReferenceIdEmailAsync(string toEmail, string referenceId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_sendGridApiKey))
                {
                    throw new Exception("SendGrid API key is not configured.");
                }

                var client = new SendGridClient(_sendGridApiKey);
                var from = new EmailAddress(_fromEmail, _fromName);
                var to = new EmailAddress(toEmail);
                
                var msg = MailHelper.CreateSingleTemplateEmail(from, to, _templateId, new
                {
                    reference_id = referenceId
                });

                var response = await client.SendEmailAsync(msg);

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to send email. StatusCode: {response.StatusCode}");
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending email: {ex.Message}");
                return false;
            }
        }
    }
}