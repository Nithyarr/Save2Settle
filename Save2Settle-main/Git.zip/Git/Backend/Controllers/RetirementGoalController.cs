﻿using Microsoft.AspNetCore.Mvc;
using RPT.Data;
using RPT.Models;
using RPT.Services;
using Microsoft.AspNetCore.Authorization;

namespace RPT.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class RetirementGoalController : ControllerBase
    {
        private readonly JsonDataService _dataService;
        private readonly IEmailService _emailService;

        public RetirementGoalController(JsonDataService dataService, IEmailService emailService)
        {
            _dataService = dataService;
            _emailService = emailService;
        }

        [HttpPost]
        [ProducesResponseType(typeof(RetirementGoal), StatusCodes.Status201Created)]
        public IActionResult CreateGoal([FromBody] CreateRetirementGoalRequest request)
        {
            try
            {
                var goal = new RetirementGoal
                {
                    CurrentAge = request.CurrentAge,
                    RetirementAge = request.RetirementAge,
                    CurrentSavings = request.CurrentSavings,
                    TargetSavings = request.TargetSavings,
                    MonthlyContribution = request.MonthlyContribution
                };

                _dataService.SaveGoal(goal);
                return CreatedAtAction(nameof(GetGoal), new { id = goal.Id }, goal);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating the retirement goal.", error = ex.Message });
            }
        }

        [Authorize]
        [HttpGet("{id}")]
        public IActionResult GetGoal(string id)
        {
            try
            {
                var goal = _dataService.GetGoalById(id);
                return goal != null ? Ok(goal) : NotFound();
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the retirement goal.", error = ex.Message });
            }
        }

        [Authorize]
        [HttpPost("/api/monthlysavings")]
        public IActionResult CalculateMonthlySavings([FromBody] RetirementGoal input)
        {
            try
            {
                double monthly = RetirementCalculator.CalculateRequiredMonthlyContribution(
                    input.CurrentSavings, input.TargetSavings, input.CurrentAge, input.RetirementAge, 6);

                return Ok(new { RequiredMonthlySavings = monthly });
            }   
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while calculating monthly savings.", error = ex.Message });
            }
        }

        [Authorize]
        [HttpPut("{id}")]
        [ProducesResponseType(typeof(RetirementGoal), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult UpdateGoal(string id, [FromBody] CreateRetirementGoalRequest updatedGoal)
        {
            try
            {
                var existingGoal = _dataService.GetGoalById(id);
                if (existingGoal == null)
                {
                    return NotFound();
                }

                existingGoal.CurrentAge = updatedGoal.CurrentAge;
                existingGoal.RetirementAge = updatedGoal.RetirementAge;
                existingGoal.CurrentSavings = updatedGoal.CurrentSavings;
                existingGoal.TargetSavings = updatedGoal.TargetSavings;
                existingGoal.MonthlyContribution = updatedGoal.MonthlyContribution;

                _dataService.UpdateGoal(existingGoal);

                return Ok(existingGoal);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the retirement goal.", error = ex.Message });
            }
        }

        [Authorize]
        [HttpGet("/api/retirementprogress/{id}")]
        public IActionResult GetProgress(string id)
        {
            try
            {
                var goal = _dataService.GetGoalById(id);
                if (goal == null) return NotFound();

                double projected = RetirementCalculator.CalculateFutureValue(
                    goal.CurrentSavings, goal.MonthlyContribution, 6, goal.RetirementAge, goal.CurrentAge);

                double idealProjected = RetirementCalculator.CalculateFutureValue(
                    goal.CurrentSavings,
                    RetirementCalculator.CalculateRequiredMonthlyContribution(goal.CurrentSavings, goal.TargetSavings,
                        goal.CurrentAge, goal.RetirementAge, 6), 6, goal.RetirementAge, goal.CurrentAge);

                return Ok(new
                {
                    CurrentProjection = projected,
                    RequiredProjection = idealProjected,
                    Target = goal.TargetSavings
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving retirement progress.", error = ex.Message });
            }
        }

        [HttpPost("send-email")]
        public async Task<IActionResult> SendReferenceEmail([FromBody] EmailRequest request)
        {
            try
            {
                var result = await _emailService.SendReferenceIdEmailAsync(request.Email, request.ReferenceId);
                if (result)
                    return Ok(new { Message = "Email sent successfully" });
                else
                    return StatusCode(500, "Failed to send email");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while sending the email.", error = ex.Message });
            }
        }

        public class EmailRequest
        {
            public string Email { get; set; }
            public string ReferenceId { get; set; }
        }
    }
}