using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using RPT.Models;
using System.Linq;

namespace YourNamespace.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly JwtSettings _jwtSettings;
        private readonly string _usersFilePath = Path.Combine("Data", "users.json");

        public AuthController(IOptions<JwtSettings> jwtSettings)
        {
            _jwtSettings = jwtSettings.Value;
        }

       [HttpPost("login")]
public IActionResult Login([FromBody] Users login)
{
    try
    {
        var users = LoadUsers();
        var user = users.FirstOrDefault(u => u.Username == login.Username && u.Password == login.Password);

        if (user != null)
        {
            var token = GenerateToken(user.Username, user.FullName);
            var refreshToken = GenerateRefreshToken(user.Username); // Correctly generate the refresh token
            return Ok(new { Token = token, RefreshToken = refreshToken, FullName = user.FullName });
        }

        return Unauthorized("Invalid Credentials");
    }
    catch (Exception ex)
    {
        return StatusCode(500, new { message = "An error occurred during login.", error = ex.Message });
    }
}


        [HttpPost("register")]
        public IActionResult Register([FromBody] Users newUser)
        {
            try
            {
                var users = LoadUsers();

                if (users.Any(u => u.Username == newUser.Username))
                {
                    return BadRequest(new { message = "User already exists." });
                }

                users.Add(newUser);
                SaveUsers(users);

                return Ok(new { message = "User registered successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during registration.", error = ex.Message });
            }
        }

        private List<Users> LoadUsers()
        {
            try
            {
                if (!System.IO.File.Exists(_usersFilePath))
                    return new List<Users>();

                var json = System.IO.File.ReadAllText(_usersFilePath);
                return JsonSerializer.Deserialize<List<Users>>(json) ?? new List<Users>();
            }
            catch (Exception ex)
            {
                throw new Exception("Error loading users from file.", ex);
            }
        }

        private void SaveUsers(List<Users> users)
        {
            try
            {
                var json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
                System.IO.File.WriteAllText(_usersFilePath, json);
            }
            catch (Exception ex)
            {
                throw new Exception("Error saving users to file.", ex);
            }
        }

        private string GenerateToken(string username, string fullName)
        {
            try
            {
                var claims = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, username),
                    new Claim("FullName", fullName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(
                    issuer: _jwtSettings.Issuer,
                    audience: _jwtSettings.Audience,
                    claims: claims,
                    expires: DateTime.Now.AddMinutes(_jwtSettings.ExpiresInMinutes),
                    signingCredentials: creds
                );

                return new JwtSecurityTokenHandler().WriteToken(token);
            }
            catch (Exception ex)
            {
                throw new Exception("Error generating JWT token.", ex);
            }
        }

       private string GenerateRefreshToken(string username)
{
    try
            {
                var claims = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, username),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };

                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(
                    issuer: _jwtSettings.Issuer,
                    audience: _jwtSettings.Audience,
                    claims: claims,
                    expires: DateTime.Now.AddMinutes(_jwtSettings.ExpiresInMinutes),
                    signingCredentials: creds
                );

                return new JwtSecurityTokenHandler().WriteToken(token);
            }
            catch (Exception ex)
            {
                throw new Exception("Error generating JWT token.", ex);
            }
}


        private string ValidateRefreshToken(string refreshToken)
        {
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jsonToken = handler.ReadToken(refreshToken) as JwtSecurityToken;

                if (jsonToken == null)
                    return null;

                var usernameClaim = jsonToken?.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Sub);
                return usernameClaim?.Value;
            }
            catch (Exception ex)
            {
                throw new Exception("Invalid refresh token.", ex);
            }
        }
    }
}
