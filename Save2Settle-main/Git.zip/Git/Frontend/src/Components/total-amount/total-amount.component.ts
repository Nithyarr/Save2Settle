import { Component } from '@angular/core';

@Component({
  selector: 'app-total-amount',
  imports: [],
  templateUrl: './total-amount.component.html',
  styleUrl: './total-amount.component.css'
})
export class TotalAmountComponent {

}
