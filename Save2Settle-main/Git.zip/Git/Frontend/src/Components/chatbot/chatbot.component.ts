import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  OnInit,
  HostListener,
  AfterViewChecked,
  OnDestroy,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { chatbotConfig } from '../../app/Config/chatbot-settings';
import { environment } from '../../Environments/environments';
import { RetirementAdvisorService } from '../../Services/gemini-ai.service';

interface RetirementData {
  currentAge?: number;
  currentSavings?: number;
  retirementAge?: number;
  targetSavings?: number;
  monthlyContribution?: number;
}

interface ChatMessage {
  text: string;
  sender: 'user' | 'bot';
  options?: string[];
}

@Component({
  selector: 'app-chatbot',
  standalone: true,
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.css'],
  imports: [FormsModule, CommonModule],
})
export class ChatbotComponent implements OnInit, AfterViewChecked, OnDestroy {
  @Output() retrieveGoalEvent = new EventEmitter<string>();
  @Input() chatBot: boolean = true;

  private baseUrl = environment.apiBaseUrl;
  private goalEndpoint = environment.endpoints.retirementGoal;
  private monthlyEndpoint = environment.endpoints.monthlySavings;
  @ViewChild('chatMessages') private chatMessagesContainer!: ElementRef;
  @ViewChild('userInputField') private userInputField!: ElementRef;
  @Output() closeBot = new EventEmitter<boolean>();
  loading: boolean = false;

  closeChat() {
    this.closeBot.emit();
  }

  mode:
    | 'create'
    | 'calculate'
    | 'retrieve'
    | 'update'
    | 'create-confirm'
    | 'calculate-confirm'
    | 'update-confirm'
    | 'help'
    | null = null;

  userInput = '';
  messages: ChatMessage[] = [];
  step = 0;
  retirementData: RetirementData = {};
  isTyping = false;
  typingTimeout: any;
  idleTimer: any;
  lastActivity: number = Date.now();
  IDLE_TIMEOUT = 120000;
  showSuggestionChips = true;
  expectingInvestmentYes = false;
  goalId: string | null = null;

  constructor(
    private http: HttpClient,
    private retirementAdvisor: RetirementAdvisorService
  ) {}
  ngAfterViewChecked(): void {
    this.scrollToBottom();
  }

  steps = chatbotConfig.steps;

  ngOnInit() {
    this.welcomeMessage();
    this.startIdleTimer();
  }

  simplePatterns: [RegExp, string[]][] = chatbotConfig.simplePatterns;

  handleSimplePatterns(input: string): boolean {
    for (const [pattern, responses] of this.simplePatterns) {
      const match = input.match(pattern);
      if (match) {
        const response =
          responses[Math.floor(Math.random() * responses.length)];
        const formatted = response.replace(
          /\$(\d+)/g,
          (_, i) => match[+i] || ''
        );
        this.addBotMessage(formatted);
        return true;
      }
    }
    return false;
  }

  @HostListener('window:keydown')
  @HostListener('window:click')
  @HostListener('window:mousemove')
  onUserActivity() {
    this.lastActivity = Date.now();
  }

  startIdleTimer() {
    this.idleTimer = setInterval(() => {
      if (Date.now() - this.lastActivity > this.IDLE_TIMEOUT) {
        this.sendIdleMessage();
      }
    }, 30000);
  }

  sendIdleMessage() {
    if (
      this.messages.length > 0 &&
      this.messages[this.messages.length - 1].sender !== 'bot'
    ) {
      this.addBotMessage(
        "I'm still here! Do you need help with your retirement planning?"
      );
    }
  }

  welcomeMessage() {
    const fullName = localStorage.getItem('fullName') || 'User';
    const firstName = fullName.split(' ')[0];
    this.addBotMessage(chatbotConfig.welcomeMessage(firstName), [
      'Create a retirement goal',
      'Calculate monthly savings',
      'Retrieve existing goal',
      'Update existing goal',
    ]);
  }

  addBotMessage(text: string, options?: string[]) {
    this.isTyping = true;
    const delay = Math.min(Math.max(text.length * 10, 300), 1500);

    clearTimeout(this.typingTimeout);
    this.typingTimeout = setTimeout(() => {
      this.isTyping = false;
      this.messages.push({
        text,
        sender: 'bot',
        options: this.showSuggestionChips ? options : undefined,
      });
      this.focusInputField();
    }, delay);
  }

  selectMode(mode: 'create' | 'calculate' | 'retrieve' | 'update' | 'help') {
    this.mode = mode;
    this.step = 0;
    this.retirementData = {};
    this.goalId = null;

    if (mode === 'retrieve') {
      this.addBotMessage(chatbotConfig.retrievePrompt);
    } else if (mode === 'update') {
      this.addBotMessage('Please enter the goal ID you want to update:');
    } else {
      this.addBotMessage(this.steps[0] + this.getExampleForCurrentStep());
    }
  }

  getExampleForCurrentStep(): string {
    const examples = ['30', '100000', '60', '5000000', '5000'];
    return this.step < examples.length
      ? ` <p class="text-sm font-light">For example: ${examples[this.step]}</p>`
      : '';
  }

  async sendMessage() {
    if (!this.userInput.trim()) return;

    const input = this.userInput.trim();
    this.messages.push({ text: input, sender: 'user' });

    const lowerInput = input.toLowerCase();

    // Check for commands first
    if (this.handleCommands(lowerInput)) {
      this.userInput = '';
      return;
    }
    if (this.expectingInvestmentYes) {
      this.expectingInvestmentYes = false;
      if (['yes', 'y'].includes(lowerInput)) {
        const advice =
          await this.retirementAdvisor.getInvestmentAdviceFromLocalStorage();
        this.addBotMessage(advice);
        this.mode = null;
      } else {
        this.addBotMessage(
          'No problem! Let me know if you want investment advice later.'
        );
        this.mode = null;
      }
      this.loading = false;
      this.userInput = '';
      return;
    }

    if (!this.mode) {
      if (input === '1' || lowerInput.includes('create'))
        this.selectMode('create');
      else if (input === '2' || lowerInput.includes('calculate'))
        this.selectMode('calculate');
      else if (input === '3' || lowerInput.includes('retrieve'))
        this.selectMode('retrieve');
      else if (input === '4' || lowerInput.includes('update'))
        this.selectMode('update');
      else if (lowerInput === 'help') this.selectMode('help');
      else if (this.handleSimplePatterns(input)) {
      } else {
        // If no pattern matched, show the default mode selection prompt
        this.addBotMessage(chatbotConfig.chooseModePrompt, [
          'Create a retirement goal',
          'Calculate monthly savings',
          'Retrieve existing goal',
          'Update existing goal',
        ]);
      }
      this.userInput = '';
      return;
    }
    if (this.mode === 'update' && !this.goalId) {
      const idPattern = /^[A-Za-z0-9]+$/;
      if (!idPattern.test(input)) {
        this.addBotMessage('Invalid goal ID format. Please enter a valid ID.');
        this.userInput = '';
        return;
      }

      this.http
        .get<any>(`${this.baseUrl}/${this.goalEndpoint}/${input.toUpperCase()}`)
        .subscribe({
          next: (res) => {
            this.retirementData = { ...res };
            this.goalId = res.id;
            this.addBotMessage(
              'Goal loaded! Let’s begin editing. ' +
                this.steps[0] +
                this.getExampleForCurrentStep()
            );
            this.mode = 'update';
            this.step = 0;
          },
          error: () => {
            this.addBotMessage(
              'Goal not found. Please check the ID and try again.',
              ['Try again', 'Start over']
            );
            this.mode = null;
          },
        });

      this.userInput = '';
      return;
    }

    if (
      this.mode === 'create-confirm' ||
      this.mode === 'calculate-confirm' ||
      this.mode === 'update-confirm'
    ) {
      if (['yes', 'y'].includes(lowerInput)) {
        const action = this.mode.split('-')[0] as
          | 'create'
          | 'calculate'
          | 'update';
        this.sendToApi(action);
      } else if (['no', 'n'].includes(lowerInput)) {
        this.addBotMessage(
          '❌ Confirmation cancelled. What would you like to do?',
          ['Go back to edit', 'Start over', 'Exit']
        );
      } else {
        this.addBotMessage('Please confirm with "yes" or "no".');
      }
      this.userInput = '';
      return;
    }

    if (this.mode === 'retrieve') {
      const idPattern = /^[A-Za-z0-9]+$/;
      if (!idPattern.test(input)) {
        this.addBotMessage(
          'Please enter a valid goal ID (letters and numbers only).'
        );
        this.userInput = '';
        return;
      }

      this.retrieveGoal(input);
      this.retrieveGoalEvent.emit(input.toUpperCase());
      this.userInput = '';
      return;
    }

    this.processStepInput(input);
    this.userInput = '';

    // Fallback pattern handled in processStepInput or handleSimplePatterns
  }

  processStepInput(input: string) {
    const number = +input;
    const isNumber = !isNaN(number) && number >= 0;

    switch (this.step) {
      case 0:
        if (!isNumber || number < 18 || number > 100)
          return this.addBotMessage(chatbotConfig.invalidInputs.age);
        this.retirementData.currentAge = number;
        break;
      case 1:
        if (!isNumber)
          return this.addBotMessage(chatbotConfig.invalidInputs.savings);
        this.retirementData.currentSavings = number;
        break;
      case 2:
        if (
          !isNumber ||
          number <= this.retirementData.currentAge! ||
          number > 100
        )
          return this.addBotMessage(chatbotConfig.invalidInputs.retirementAge);
        this.retirementData.retirementAge = number;
        break;
      case 3:
        if (!isNumber || number <= 0)
          return this.addBotMessage(chatbotConfig.invalidInputs.targetSavings);
        this.retirementData.targetSavings = number;
        break;
      case 4:
        if (!isNumber)
          return this.addBotMessage(
            chatbotConfig.invalidInputs.monthlyContribution
          );
        this.retirementData.monthlyContribution = number;
        this.confirmSubmission();
        return;
    }

    this.step++;
    if (this.step < this.steps.length) {
      this.addBotMessage(
        this.steps[this.step] + this.getExampleForCurrentStep()
      );
    }
  }

  confirmSubmission() {
    this.addBotMessage(
      chatbotConfig.confirmationMessage(
        this.retirementData as Required<RetirementData>
      ),
      ['Yes', 'No']
    );

    if (this.goalId) {
      this.mode = 'update-confirm';
    } else if (this.mode === 'calculate') {
      this.mode = 'calculate-confirm';
    } else {
      this.mode = 'create-confirm';
    }
  }

  sendToApi(type: 'create' | 'calculate' | 'update') {
    this.addBotMessage('Please wait while I process your request...');

    let url = '';
    let method: any = this.http.post;

    if (type === 'create') {
      url = `${this.baseUrl}/${this.goalEndpoint}`;
    } else if (type === 'calculate') {
      url = `${this.baseUrl}/${this.monthlyEndpoint}`;
    } else if (type === 'update' && this.goalId) {
      url = `${this.baseUrl}/${this.goalEndpoint}/${this.goalId}`;
      method = this.http.put;
    }

    if (!this.validateDataBeforeSending()) {
      this.addBotMessage(
        'Some information appears to be missing. Please try again.'
      );
      this.mode = null;
      return;
    }

    method.call(this.http, url, this.retirementData).subscribe({
      next: (res: any) => {
        if (type === 'create') {
          this.expectingInvestmentYes = true;
          localStorage.setItem(
            'retirementData',
            JSON.stringify(this.getCustomPayload())
          );
          this.addBotMessage(
            chatbotConfig.createSuccess(res.id) +
              '<br>Would you like some advice on where to invest your savings?',
            ['Calculate monthly savings', 'Start over', 'Exit', 'Yes', 'No']
          );
        } else if (type === 'update') {
          this.addBotMessage(`Goal updated successfully! ID: ${res.id}`, [
            'Start over',
            'Exit',
          ]);
        } else {
          this.expectingInvestmentYes = true;
          localStorage.setItem(
            'retirementData',
            JSON.stringify(this.getCustomPayload())
          );
          this.addBotMessage(
            chatbotConfig.calculationSuccess(res.requiredMonthlySavings) +
              '<br>Would you like some investment suggestions?',
            ['Create a retirement goal', 'Start over', 'Exit', 'Yes', 'No']
          );
        }
        this.reset();
      },
      error: (err: { status: any }) => {
        console.error('API Error:', err);

        if (err.status === 404) {
          this.addBotMessage('Goal not found. Please try again.');
        } else {
          this.addBotMessage(
            'Oops! Something went wrong. Please try again later.'
          );
        }
      },
    });
  }

  validateDataBeforeSending(): boolean {
    const data = this.retirementData;
    return (
      data.currentAge !== undefined &&
      data.currentSavings !== undefined &&
      data.retirementAge !== undefined &&
      data.targetSavings !== undefined &&
      data.monthlyContribution !== undefined
    );
  }

  getCustomPayload() {
    // Maps internal RetirementData to the required API payload format
    return {
      currentAge: this.retirementData.currentAge ?? '',
      currentSave: this.retirementData.currentSavings ?? '',
      monthlSave: this.retirementData.monthlyContribution ?? '',
      targetAge: this.retirementData.retirementAge ?? '',
      targetSave: this.retirementData.targetSavings ?? '',
    };
  }
  retrieveGoal(id: string) {
    this.addBotMessage('Fetching your goal, please wait...');
    this.http
      .get<any>(`${this.baseUrl}/${this.goalEndpoint}/${id.toUpperCase()}`)
      .subscribe({
        next: (res) => {
          const mapped = {
            currentAge: res.currentAge ?? '',
            currentSave: res.currentSavings ?? '',
            monthlSave: res.monthlyContribution ?? '',
            targetAge: res.retirementAge ?? '',
            targetSave: res.targetSavings ?? '',
          };
          localStorage.setItem('retirementData', JSON.stringify(mapped));
          this.retirementData = { ...res };
          this.expectingInvestmentYes = true;
          this.goalId = res.id;
          this.addBotMessage(
            `Goal details:<br>
            Current Age: ${res.currentAge}<br>
            Current Savings: ${res.currentSavings}<br>
            Retirement Age: ${res.retirementAge}<br>
            Target Savings: ${res.targetSavings}<br>
            Monthly Contribution: ${res.monthlyContribution}<br><br>
            Would you like to get investment suggestions based on this goal?`,
            ['Yes', 'No']
          );
          this.mode = null;
        },
        error: () => {
          this.addBotMessage(
            'Goal not found. Please check the ID and try again.'
          );
        },
      });
  }

  handleCommands(input: string): boolean {
    if (input === 'help') {
      this.addBotMessage(chatbotConfig.commandsHelp, [
        'Create a retirement goal',
        'Calculate monthly savings',
        'Retrieve existing goal',
        'Update existing goal',
      ]);
      return true;
    } else if (input === 'exit' || input === 'quit') {
      this.addBotMessage('Thank you for using the chatbot. Goodbye!');
      this.reset();
      return true;
    }
    return false;
  }

  reset() {
    this.mode = null;
    this.step = 0;
    this.retirementData = {};
    this.goalId = null;
  }

  focusInputField() {
    setTimeout(() => {
      if (this.userInputField) {
        this.userInputField.nativeElement.focus();
      }
    }, 200);
  }

  private scrollToBottom(): void {
    try {
      if (
        this.chatMessagesContainer &&
        this.chatMessagesContainer.nativeElement
      ) {
        this.chatMessagesContainer.nativeElement.scrollTop =
          this.chatMessagesContainer.nativeElement.scrollHeight;
      }
    } catch (err) {
      console.error('Scroll error:', err);
    }
  }

  ngOnDestroy() {
    clearInterval(this.idleTimer);
    clearTimeout(this.typingTimeout);
  }
}
