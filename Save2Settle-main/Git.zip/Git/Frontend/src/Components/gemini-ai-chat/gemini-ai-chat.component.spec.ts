import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeminiAiChatComponent } from './gemini-ai-chat.component';

describe('GeminiAiChatComponent', () => {
  let component: GeminiAiChatComponent;
  let fixture: ComponentFixture<GeminiAiChatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GeminiAiChatComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GeminiAiChatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
