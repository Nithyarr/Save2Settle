import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RetirementAdvisorService } from '../../Services/gemini-ai.service';

export interface Message {
  type: 'user' | 'ai';
  text: string;
}

@Component({
  selector: 'app-gemini-ai-chat',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './gemini-ai-chat.component.html',
  styleUrls: ['./gemini-ai-chat.component.css'],
})
export class GeminiAiChatComponent {
  @ViewChild('chatWindow') private chatWindow!: ElementRef;

  userMessage: string = '';
  messages: Message[] = [];
  loading = false;

  constructor(private retirementAdvisor: RetirementAdvisorService) {
    this.startConversation();
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  private scrollToBottom(): void {
    try {
      this.chatWindow.nativeElement.scrollTop =
        this.chatWindow.nativeElement.scrollHeight;
    } catch (err) {
      console.error('Scroll error', err);
    }
  }

  startConversation() {
    const greeting = `Hi, I'm your Retirement Planner 🤖. Let's get started! Please type your retirement details or ask for investment advice.`;
    this.messages.push({ type: 'ai', text: greeting });
  }

  async sendMessage() {
    if (!this.userMessage.trim()) return;

    // Add user message to chat window
    this.messages.push({ type: 'user', text: this.userMessage.trim() });
    this.loading = true;

    try {
      // Call service to get AI advice based on localStorage data
      const advice = await this.retirementAdvisor.getInvestmentAdviceFromLocalStorage();
      this.messages.push({ type: 'ai', text: advice });
    } catch (error) {
      this.messages.push({
        type: 'ai',
        text: 'Sorry, I could not fetch investment advice right now.',
      });
      console.error(error);
    } finally {
      this.loading = false;
      this.userMessage = '';
    }
  }
}
