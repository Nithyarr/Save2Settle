// chatbot-config.ts
export const chatbotConfig = {
  welcomeMessage: (userName: string) =>
    `Hi, <b>${userName}</b>!👋 <br>I am your Retirement Assistant ChatBot.<br>What would you like to do?<br><b>1.</b> Create Goal<br><b>2.</b> Calculate Monthly Savings<br><b>3.</b> Search Goal by ID<br> <b>4.</b> Update Goal<br>Type <b>help</b> for commands.`,

  steps: [
    'What is your current age?',
    'What is your current savings?',
    'What age do you want to retire?',
    'What is your retirement savings goal?',
    'How much do you contribute monthly?',
  ],
  simplePatterns: [
    [
      /hi|hello|hey/i,
      [
        'Hello! Ready to plan your retirement? How can I help you today?',
        'Hi there! Need assistance with your retirement goals?',
      ],
    ],
    [
      /my name is (.*)/i,
      [
        "Hello $1! Let's make your retirement plan great. How can I assist you today?",
      ],
    ],
    [/(.*) your name\??/i, ['I am your Retirement Planning Assistant!']],
    [
      /how are you\??/i,
      ["I'm here to help you plan your retirement. How can I assist you?"],
    ],
    [
      /tell me a joke/i,
      [
        'Why don’t retirees mind being called seniors? Because it comes with a 10% discount!',
      ],
    ],
    [
      /(.*) (help|assist) (.*)/i,
      ['Sure! I can assist you with $3 related to retirement planning.'],
    ],

    // Retirement age questions
    [
      /(.*)(retirement age|when to retire)(.*)/i,
      [
        'Most people retire between 60 and 70 years old. What age are you thinking about?',
      ],
    ],

    // Savings goal questions
    [
      /(.*)(savings goal|target savings)(.*)/i,
      [
        'Setting a savings goal is important! What target amount do you have in mind?',
      ],
    ],

    // Monthly contribution questions
    [
      /(.*)(monthly contribution|save per month)(.*)/i,
      [
        "Let's calculate how much you need to save monthly. What is your current monthly savings?",
      ],
    ],

    // Current savings questions
    [
      /(.*)(current savings|how much saved)(.*)/i,
      [
        'Knowing your current savings helps us plan better. How much have you saved so far?',
      ],
    ],

    // Retirement income questions
    [
      /(.*)(retirement income|income after retirement)(.*)/i,
      [
        'Are you expecting any income sources during retirement like pension or investments?',
      ],
    ],

    // Investment risk tolerance
    [
      /(.*)(risk tolerance|investment risk)(.*)/i,
      [
        'Understanding your risk tolerance is key. Do you prefer safe investments or are you comfortable with some risk?',
      ],
    ],

    // Retirement duration questions
    [
      /(.*)(how long will retirement last|retirement duration)(.*)/i,
      [
        'Typically, retirement can last 20-30 years. How long do you expect yours to be?',
      ],
    ],

    // Inflation impact questions
    [
      /(.*)(inflation|inflation impact)(.*)/i,
      [
        'Inflation can affect your savings. Do you want to factor inflation into your plan?',
      ],
    ],

    // Early retirement queries
    [
      /(.*)(early retirement)(.*)/i,
      ['Early retirement sounds great! What age are you aiming for?'],
    ],

    // Retirement expenses questions
    [
      /(.*)(retirement expenses|monthly expenses)(.*)/i,
      [
        'Estimating your monthly expenses during retirement helps plan better. Any estimates?',
      ],
    ],

    // Social security questions
    [
      /(.*)(social security|pension)(.*)/i,
      [
        'Do you expect to receive social security or pension benefits? If yes, when?',
      ],
    ],

    // Goodbye
    [
      /bye|exit/i,
      [
        'Goodbye! Wishing you a secure retirement!',
        'See you later! Stay financially wise!',
      ],
    ],

    // Fallback for unmatched input
    [
      /(.*)/i,
      [
        "I'm sorry, I didn't understand that. Could you please ask about your retirement plan?",
        'Could you please elaborate your retirement question?',
      ],
    ],
  ] as [RegExp, string[]][],
  chooseModePrompt: 'Please choose 1, 2, or 3. Type "help" for options.',

  invalidInputs: {
    age: 'Please enter a valid age between 18 and 100.',
    savings: 'Enter a valid number for current savings.',
    retirementAge: 'Retirement age must be greater than current age.',
    targetSavings: 'Enter a valid number for target savings.',
    monthlyContribution: 'Enter a valid monthly contribution amount.',
  },

  commandsHelp: `<b>Commands:</b><br>1 / create - Create Retirement Goal<br>2 / calculate - Calculate Monthly Savings<br>3 / retrieve - Retrieve Goal by ID<br>back - Go to previous question<br>restart - Restart the conversation<br>exit - End chat`,

  restartMessage: 'Restarting conversation...',
  exitMessage: '👋 Thank you! Goodbye!',
  backMessagePrefix: '↩️ Going back. ',

  confirmationMessage: (data: {
    currentAge: number;
    currentSavings: number;
    retirementAge: number;
    targetSavings: number;
    monthlyContribution: number;
  }) =>
    `📝 Please confirm your inputs:<br>- Current Age: ${data.currentAge}<br>- Current Savings: ₹${data.currentSavings}<br>- Retirement Age: ${data.retirementAge}<br>- Target Savings: ₹${data.targetSavings}<br>- Monthly Contribution: ₹${data.monthlyContribution}<br>Type "yes" to confirm or "back" to revise.`,

  createSuccess: (id: string) => `Successfully Goal Created! ID: ${id}`,
  calculationSuccess: (requiredMonthlySavings: number) =>
    `Required Monthly Savings: $${requiredMonthlySavings.toFixed(2)}`,
  errorMessage: '❌ Something went wrong. Try again later.',
  retrievePrompt: 'Please enter the Goal ID to retrieve:',
  searchingMessage: (id: string) =>
    `🔍 Searching goal with ID: ${id.toUpperCase()}...`,
  goalNotFoundMessage: '❌ Goal not found or invalid ID.',
};
