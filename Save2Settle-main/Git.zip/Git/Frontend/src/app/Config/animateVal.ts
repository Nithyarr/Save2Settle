import { chartSettings } from './chart-settings';

export const animateValue = (target: number, setter: (val: number) => void) => {
  {
    let currentValue = 0;
    const duration = chartSettings.animate.duration;
    const frameRate = chartSettings.animate.framerate;
    const increment =
      target / (duration / (chartSettings.animate.increment / frameRate));

    const interval = setInterval(() => {
      if (currentValue < target) {
        currentValue += increment;
        setter(Math.floor(currentValue));
      } else {
        clearInterval(interval);
        setter(Math.round(target));
      }
    }, 1000 / frameRate);
  }
};
