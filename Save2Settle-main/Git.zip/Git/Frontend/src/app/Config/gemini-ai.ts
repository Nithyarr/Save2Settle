export const APIKEY = {
  API: 'AIzaSyAJA1J-F200bfRMjuthvyTfMWNmR-5DBuY',
};
