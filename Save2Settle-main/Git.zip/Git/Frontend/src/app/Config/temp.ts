import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  OnInit,
  HostListener,
  AfterViewChecked,
  OnDestroy,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { chatbotConfig } from '../../app/Config/chatbot-settings';
import { environment } from '../../Environments/environments';
import { RetirementAdvisorService } from '../../Services/gemini-ai.service';

interface RetirementData {
  currentAge?: number;
  currentSavings?: number;
  retirementAge?: number;
  targetSavings?: number;
  monthlyContribution?: number;
}

interface ChatMessage {
  text: string;
  sender: 'user' | 'bot';
  options?: string[];
}

export class  {
  @Output() retrieveGoalEvent = new EventEmitter<string>();
  @Input() chatBot: boolean = true;
  @Output() closeBot = new EventEmitter<boolean>();

  @ViewChild('chatMessages') private chatMessagesContainer!: ElementRef;
  @ViewChild('userInputField') private userInputField!: ElementRef;

  mode:
    | 'create'
    | 'calculate'
    | 'retrieve'
    | 'update'
    | 'create-confirm'
    | 'calculate-confirm'
    | 'update-confirm'
    | 'help'
    | null = null;

  userInput = '';
  messages: ChatMessage[] = [];
  step = 0;
  retirementData: RetirementData = {};
  isTyping = false;
  typingTimeout: any;
  idleTimer: any;
  lastActivity: number = Date.now();
  IDLE_TIMEOUT = 120000;
  showSuggestionChips = true;
  goalId: string | null = null;
  expectingInvestmentYes = false;
  loading = false;

  private baseUrl = environment.apiBaseUrl;
  private goalEndpoint = environment.endpoints.retirementGoal;
  private monthlyEndpoint = environment.endpoints.monthlySavings;

  constructor(
    private http: HttpClient,
    private retirementAdvisor: RetirementAdvisorService
  ) {}

  steps = chatbotConfig.steps;
  simplePatterns: [RegExp, string[]][] = chatbotConfig.simplePatterns;

  ngOnInit() {
    this.welcomeMessage();
    this.startIdleTimer();
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  ngOnDestroy() {
    clearInterval(this.idleTimer);
    clearTimeout(this.typingTimeout);
  }

  @HostListener('window:keydown')
  @HostListener('window:click')
  @HostListener('window:mousemove')
  onUserActivity() {
    this.lastActivity = Date.now();
  }

  startIdleTimer() {
    this.idleTimer = setInterval(() => {
      if (Date.now() - this.lastActivity > this.IDLE_TIMEOUT) {
        this.sendIdleMessage();
      }
    }, 30000);
  }

  sendIdleMessage() {
    if (
      this.messages.length > 0 &&
      this.messages[this.messages.length - 1].sender !== 'bot'
    ) {
      this.addBotMessage(
        "I'm still here! Do you need help with your retirement planning?"
      );
    }
  }

  welcomeMessage() {
    const fullName = localStorage.getItem('fullName') || 'User';
    const firstName = fullName.split(' ')[0];
    this.addBotMessage(chatbotConfig.welcomeMessage(firstName), [
      'Create a retirement goal',
      'Calculate monthly savings',
      'Retrieve existing goal',
      'Update existing goal',
    ]);
  }

  closeChat() {
    this.closeBot.emit(false);
  }

  addBotMessage(text: string, options?: string[]) {
    this.isTyping = true;
    const delay = Math.min(Math.max(text.length * 10, 300), 1500);

    clearTimeout(this.typingTimeout);
    this.typingTimeout = setTimeout(() => {
      this.isTyping = false;
      this.messages.push({
        text,
        sender: 'bot',
        options: this.showSuggestionChips ? options : undefined,
      });
      this.scrollToBottom();
      this.focusInputField();
    }, delay);
  }

  scrollToBottom() {
    setTimeout(() => {
      if (this.chatMessagesContainer) {
        this.chatMessagesContainer.nativeElement.scrollTop =
          this.chatMessagesContainer.nativeElement.scrollHeight;
      }
    }, 100);
  }

  focusInputField() {
    setTimeout(() => this.userInputField?.nativeElement?.focus(), 100);
  }

  handleSimplePatterns(input: string): boolean {
    for (const [pattern, responses] of this.simplePatterns) {
      const match = input.match(pattern);
      if (match) {
        const response =
          responses[Math.floor(Math.random() * responses.length)];
        const formatted = response.replace(
          /\$(\d+)/g,
          (_, i) => match[+i] || ''
        );
        this.addBotMessage(formatted);
        return true;
      }
    }
    return false;
  }

  getExampleForCurrentStep(): string {
    const examples = ['30', '100000', '60', '5000000', '5000'];
    return this.step < examples.length
      ? ` <p class="text-sm font-light">For example: ${examples[this.step]}</p>`
      : '';
  }

  selectMode(mode: 'create' | 'calculate' | 'retrieve' | 'update' | 'help') {
    this.mode = mode;
    this.step = 0;
    this.retirementData = {};
    this.goalId = null;

    if (mode === 'retrieve') {
      this.addBotMessage(chatbotConfig.retrievePrompt);
    } else if (mode === 'update') {
      this.addBotMessage('Please enter the goal ID you want to update:');
    } else {
      this.addBotMessage(this.steps[0] + this.getExampleForCurrentStep());
    }
  }

  async sendMessage() {
    if (!this.userInput.trim()) return;

    const input = this.userInput.trim();
    this.messages.push({ text: input, sender: 'user' });
    this.scrollToBottom();
    const lowerInput = input.toLowerCase();

    if (this.handleCommands(lowerInput)) {
      this.userInput = '';
      return;
    }

    if (this.expectingInvestmentYes) {
      this.expectingInvestmentYes = false;
      if (['yes', 'y'].includes(lowerInput)) {
        const advice =
          await this.retirementAdvisor.getInvestmentAdviceFromLocalStorage();
        this.addBotMessage(advice);
        this.mode = null;
      } else {
        this.addBotMessage(
          'No problem! Let me know if you want investment advice later.'
        );
        this.mode = null;
      }
      this.loading = false;
      this.userInput = '';
      return;
    }

    if (!this.mode) {
      if (input === '1' || lowerInput.includes('create'))
        this.selectMode('create');
      else if (input === '2' || lowerInput.includes('calculate'))
        this.selectMode('calculate');
      else if (input === '3' || lowerInput.includes('retrieve'))
        this.selectMode('retrieve');
      else if (input === '4' || lowerInput.includes('update'))
        this.selectMode('update');
      else if (lowerInput === 'help') this.selectMode('help');
      else if (this.handleSimplePatterns(input)) {
      } else {
        this.addBotMessage(chatbotConfig.chooseModePrompt, [
          'Create a retirement goal',
          'Calculate monthly savings',
          'Retrieve existing goal',
          'Update existing goal',
        ]);
      }
      this.userInput = '';
      return;
    }

    if (this.mode === 'update' && !this.goalId) {
      const idPattern = /^[A-Za-z0-9]+$/;
      if (!idPattern.test(input)) {
        this.addBotMessage('Invalid goal ID format. Please enter a valid ID.');
        this.userInput = '';
        return;
      }

      this.http
        .get<any>(`${this.baseUrl}/${this.goalEndpoint}/${input.toUpperCase()}`)
        .subscribe({
          next: (res) => {
            this.retirementData = { ...res };
            this.goalId = res.id;
            this.addBotMessage(
              'Goal loaded! Let’s begin editing. ' +
                this.steps[0] +
                this.getExampleForCurrentStep()
            );
            this.mode = 'update';
            this.step = 0;
          },
          error: () => {
            this.addBotMessage(
              'Goal not found. Please check the ID and try again.',
              ['Try again', 'Start over']
            );
            this.mode = null;
          },
        });

      this.userInput = '';
      return;
    }

    if (
      this.mode === 'create-confirm' ||
      this.mode === 'calculate-confirm' ||
      this.mode === 'update-confirm'
    ) {
      if (['yes', 'y'].includes(lowerInput)) {
        const action = this.mode.split('-')[0] as
          | 'create'
          | 'calculate'
          | 'update';
        this.sendToApi(action);
      } else if (['no', 'n'].includes(lowerInput)) {
        this.addBotMessage(
          '❌ Confirmation cancelled. What would you like to do?',
          ['Go back to edit', 'Start over', 'Exit']
        );
      } else {
        this.addBotMessage('Please confirm with "yes" or "no".');
      }
      this.userInput = '';
      return;
    }

    if (this.mode === 'retrieve') {
      const idPattern = /^[A-Za-z0-9]+$/;
      if (!idPattern.test(input)) {
        this.addBotMessage(
          'Please enter a valid goal ID (letters and numbers only).'
        );
        this.userInput = '';
        return;
      }

      this.retrieveGoal(input);
      this.retrieveGoalEvent.emit(input.toUpperCase());
      this.userInput = '';
      return;
    }

    this.processStepInput(input);
    this.userInput = '';
  }

  processStepInput(input: string) {
    const number = +input;
    const isNumber = !isNaN(number) && number >= 0;

    switch (this.step) {
      case 0:
        if (!isNumber || number < 18 || number > 100)
          return this.addBotMessage(chatbotConfig.invalidInputs.age);
        this.retirementData.currentAge = number;
        break;
      case 1:
        if (!isNumber)
          return this.addBotMessage(chatbotConfig.invalidInputs.savings);
        this.retirementData.currentSavings = number;
        break;
      case 2:
        if (
          !isNumber ||
          number <= this.retirementData.currentAge! ||
          number > 100
        )
          return this.addBotMessage(chatbotConfig.invalidInputs.retirementAge);
        this.retirementData.retirementAge = number;
        break;
      case 3:
        if (!isNumber || number <= 0)
          return this.addBotMessage(chatbotConfig.invalidInputs.targetSavings);
        this.retirementData.targetSavings = number;
        break;
      case 4:
        if (!isNumber)
          return this.addBotMessage(
            chatbotConfig.invalidInputs.monthlyContribution
          );
        this.retirementData.monthlyContribution = number;
        this.confirmSubmission();
        return;
    }

    this.step++;
    if (this.step < this.steps.length) {
      this.addBotMessage(
        this.steps[this.step] + this.getExampleForCurrentStep()
      );
    }
  }

  confirmSubmission() {
    this.addBotMessage(
      chatbotConfig.confirmationMessage(
        this.retirementData as Required<RetirementData>
      ),
      ['Yes', 'No']
    );

    if (this.goalId) this.mode = 'update-confirm';
    else if (this.mode === 'create') this.mode = 'create-confirm';
    else if (this.mode === 'calculate') this.mode = 'calculate-confirm';
  }

  sendToApi(mode: 'create' | 'calculate' | 'update') {
    const endpoint =
      mode === 'calculate'
        ? this.monthlyEndpoint
        : this.goalEndpoint +
          (mode === 'update' && this.goalId ? `/${this.goalId}` : '');

    const method = mode === 'update' ? 'put' : 'post';

    this.http[method](
      `${this.baseUrl}/${endpoint}`,
      this.retirementData
    ).subscribe({
      next: (res: any) => {
        this.addBotMessage(
          mode === 'calculate'
            ? `✅ Your estimated monthly contribution is ₹${res.monthlyContribution}`
            : `🎯 Goal ${
                mode === 'update' ? 'updated' : 'created'
              } successfully! ID: ${res.id}`
        );

        if (mode !== 'calculate') {
          this.expectingInvestmentYes = true;
          this.addBotMessage(
            'Would you like some advice on where to invest your savings?',
            ['Yes', 'No']
          );
        }
      },
      error: () => {
        this.addBotMessage('Something went wrong. Please try again later.');
      },
    });
  }

  retrieveGoal(id: string) {
    this.addBotMessage('Fetching your goal, please wait...');
    this.http
      .get<any>(`${this.baseUrl}/${this.goalEndpoint}/${id.toUpperCase()}`)
      .subscribe({
        next: (res) => {
          this.retirementData = { ...res };
          this.goalId = res.id;
          this.expectingInvestmentYes = true;
          this.addBotMessage(
            `Goal details:<br>
            Current Age: ${res.currentAge}<br>
            Current Savings: ${res.currentSavings}<br>
            Retirement Age: ${res.retirementAge}<br>
            Target Savings: ${res.targetSavings}<br>
            Monthly Contribution: ${res.monthlyContribution}<br><br>Would 
            you like to get investment suggestions based on this goal?`,
            ['Yes', 'No']
          );
        },
        error: () => {
          this.addBotMessage(
            'Goal not found. Please check the ID and try again.'
          );
        },
      });
  }

  handleCommands(input: string): boolean {
    if (input === 'help') {
      this.addBotMessage(chatbotConfig.commandsHelp, [
        'Create a retirement goal',
        'Calculate monthly savings',
        'Retrieve existing goal',
        'Update existing goal',
      ]);
      return true;
    } else if (input === 'exit' || input === 'quit') {
      this.addBotMessage('Thank you for using the chatbot. Goodbye!');
      this.reset();
      return true;
    }
    return false;
  }
  reset() {
    this.mode = null;
    this.step = 0;
    this.retirementData = {};
    this.goalId = null;
  }
}
