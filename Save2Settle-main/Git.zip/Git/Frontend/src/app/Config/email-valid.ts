export const EMAIL_CONFIG = {
  emailRegex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  invalidEmailMessage: 'Please enter a valid Email address.',
};
