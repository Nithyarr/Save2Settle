import { Component, ElementRef, QueryList, ViewChildren } from '@angular/core';
import { HeaderComponent } from '../../../Components/header/header.component';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { chartSettings } from '../../Config/chart-settings';
import { animateValue } from '../../Config/animateVal';
import { FooterComponent } from "../../../Components/footer/footer.component";
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-rule',
  standalone: true,
  imports: [HeaderComponent, CommonModule, FormsModule, ReactiveFormsModule,TranslateModule],
  templateUrl: './rule.component.html',
  styleUrl: './rule.component.css',
})
export class RuleComponent {
  @ViewChildren('tabElement') tabElements!: QueryList<ElementRef>;

  activeIndex = 0;
  activeTab: string = '25x';

  retirementForm!: FormGroup;

  // Input values
  monthlyExpenses: number = 0;
  totalSavings: number = 0;

  // Output values
  retirementGoal: number = 0;
  safeWithdrawal: number = 0;

  private multiplier = 25;
  animatedValue: number = 0;

  constructor(private elRef: ElementRef, private fb: FormBuilder) {
    this.retirementForm = this.fb.group({
      monthlyExpenses: ['', [Validators.required, Validators.min(1)]],
    });
  }

  ngOnInit(): void {
    this.retirementForm = this.fb.group({
      monthlyExpenses: [undefined],
    });

    // Optionally calculate a default retirement goal
    this.calculate25xGoal();
  }

  ngAfterViewInit() {
    setTimeout(() => this.moveIndicator(), 0);
  }

  switchTab(index: number) {
    this.activeIndex = index;
    this.moveIndicator();
  }

  moveIndicator() {
    const indicator = this.elRef.nativeElement.querySelector('.tab-indicator');
    const tab = this.tabElements.toArray()[this.activeIndex].nativeElement;
    indicator.style.width = `${tab.offsetWidth}px`;
    indicator.style.left = `${tab.offsetLeft}px`;
  }

  setTab(tab: string) {
    this.activeTab = tab;
  }

calculate25xGoal() {
    if (!this.monthlyExpenses || this.monthlyExpenses < 1) return;

    const retirementGoal = this.monthlyExpenses * 12 * 25;
    this.animatedValue = retirementGoal;
    animateValue(
      (this.animatedValue),
      (val) => (this.animatedValue = val)
    );
  }

  calculateUsing4PercentRule(): void {
    const annualExpenses = this.monthlyExpenses * 12;
    this.retirementGoal = annualExpenses / 0.04;
    this.safeWithdrawal = this.totalSavings * 0.04;
  }
  currentAge: number = 0;
  currentSavings: number = 0;
  annualContribution: number = 0;
  growthRate: number = 0.06;
  retirementAge: number | null = null;

  calculateRetirementAge(): void {
    const monthlyExpenses = this.monthlyExpenses;
    const currentSavings = this.currentSavings;
    const annualContribution = this.annualContribution;
    const currentAge = this.currentAge;
    const growthRate = this.growthRate; // assumed to be annual growth rate (e.g., 0.07 for 7%)

    const retirementGoal = monthlyExpenses * 12 * 25; // 25x Rule

    const maxAge = 100; // Optional cap to prevent infinite loops
    let age = currentAge;

    while (age <= maxAge) {
      const years = age - currentAge;

      // Future value of current savings
      const futureValueCurrentSavings =
        currentSavings * Math.pow(1 + growthRate, years);

      // Future value of annual contributions (ordinary annuity)
      const futureValueContributions =
        annualContribution *
        ((Math.pow(1 + growthRate, years) - 1) / growthRate);

      const totalFutureValue =
        futureValueCurrentSavings + futureValueContributions;

      if (totalFutureValue >= retirementGoal) {
        this.retirementAge = age;
        return;
      }

      age++;
    }

    // If retirement goal not achievable by maxAge
    this.retirementAge = -1;
  }
}
