import { Component, ElementRef, ViewChild } from '@angular/core';
import { HeaderComponent } from '../../../Components/header/header.component';
import { Router } from '@angular/router';
import { Images } from '../../Config/images';
import { ChatbotComponent } from '../../../Components/chatbot/chatbot.component';
import { FooterComponent } from "../../../Components/footer/footer.component";
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [HeaderComponent, FooterComponent,TranslateModule],
  templateUrl: './about-us.component.html',
  styleUrl: './about-us.component.css',
})
export class AboutUsComponent {
  Nithya = Images.Nithya;
  Sanjana = Images.Sanjana;
  Praveen = Images.Praveen;
  Poorva = Images.Poorva;
  Sheetal = Images.Sheetal;
  @ViewChild('myElement') myElementRef!: ElementRef;
  private darkClasses: string[] = [];
  private isDark = true;
  constructor(private router: Router) {}
  navigateToDashboard() {
    this.router.navigate(['/dashboard']);
  }
  toggleDarkClasses() {
    const el = this.myElementRef.nativeElement;
    const classList = Array.from(el.classList) as string[];

    if (this.isDark) {
      // Store dark: classes and remove them
      this.darkClasses = classList.filter((cls) => cls.startsWith('dark:'));
      this.darkClasses.forEach((cls) => el.classList.remove(cls));
    } else {
      // Add back stored dark: classes
      this.darkClasses.forEach((cls) => el.classList.add(cls));
    }

    this.isDark = !this.isDark;
  }
}
