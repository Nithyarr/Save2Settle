import { Injectable } from '@angular/core';
import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = 'AIzaSyDVkagnlS4cyevH9sgJ7Bj9WiJ9v9Pyyd8'; // Replace with your key

@Injectable({
  providedIn: 'root',
})
export class RetirementAdvisorService {
  private genAI = new GoogleGenerativeAI(API_KEY);
  private chat: any;

  constructor() {
    this.initChat();
  }

  private async initChat() {
    const model = this.genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });
    this.chat = model.startChat({ history: [] });
  }

  private buildPromptFromStoredData(goalData: any): string {
    return `You are a retirement financial advisor AI. A user has the following retirement goal data:

- Current Age: ${goalData.currentAge}
- Retirement Age: ${goalData.targetAge}
- Current Savings: ₹${goalData.currentSave}
- Target Retirement Savings: ₹${goalData.targetSave}

Calculate at 6% per annum and provide:
- A recommended investment portfolio allocation suitable for retirement planning (with % allocation to equities, debt, PPF, gold, etc.)

Keep your response short, clear, and without markdown or special formatting.`;
  }

  async getInvestmentAdviceFromLocalStorage(): Promise<string> {
    const goalData = JSON.parse(localStorage.getItem('retirementData') || '{}');

    if (
      !goalData.currentAge ||
      !goalData.targetAge ||
      !goalData.currentSave ||
      !goalData.targetSave
    ) {
      throw new Error('Incomplete retirement data in localStorage');
    }

    const prompt = this.buildPromptFromStoredData(goalData);

    try {
      const result = await this.chat.sendMessage(prompt);
      const response = await result.response;
       localStorage.removeItem('retirementData');
      return response.text();
      
    } catch (error) {
      console.error('Gemini API Error:', error);
      throw new Error('Failed to fetch advice from Gemini API');
    }
  }
}
