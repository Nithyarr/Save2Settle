// export const TRANSLATION_LANGUAGES = [
//     {
//       code: 'fr',
//       file: 'assets/i18n/fr.json'
//     },
//     {
//         code:'zh',
//         file:'assests/i18n/zh.json'
//     },
//   ];
  